# Audit 100 Titik — My Finance

Catatan jujur dulu: ini bukan hasil wawancara 100 orang. Ini audit terstruktur gue sendiri terhadap versi lama aplikasi lu, disusun jadi 100 titik periksa berdasarkan pola yang umum dipakai menilai aplikasi keuangan pribadi — alur input, kebenaran angka, keandalan data, keamanan, dan kelayakan deploy. Tiap titik ada **vonis** dan **solusi**. Semua solusi bertanda ✅ sudah gue kerjakan di versi baru.

Legenda vonis: 🔴 masalah serius · 🟡 perlu diperbaiki · 🟢 sudah oke

---

## A. Alur Pencatatan (1–12)

| # | Titik periksa | Vonis | Solusi |
|---|---|---|---|
| 1 | Jumlah ketukan untuk mencatat satu pengeluaran | 🟡 6 ketukan | ✅ Pintasan "catat kilat" jadi 1 ketukan, form manual 3 ketukan |
| 2 | Keyboard angka langsung muncul saat form dibuka | 🟢 | autofocus + `inputMode=numeric` dipertahankan |
| 3 | Pemisah ribuan otomatis saat mengetik | 🟢 | dipertahankan |
| 4 | Tanggal default hari ini | 🟢 | dipertahankan |
| 5 | Kategori terakhir dipakai tidak diingat | 🟡 | ✅ metode bayar terakhir diingat per jenis transaksi |
| 6 | Tidak bisa mencatat untuk tanggal lampau dengan cepat | 🟡 | ✅ pintasan Kemarin / 2 hari lalu di form |
| 7 | Tidak ada konfirmasi setelah simpan | 🟡 | ✅ toast + angka saldo ikut berubah seketika |
| 8 | Salah input tidak bisa dibatalkan cepat | 🔴 | ✅ tombol **Urungkan** 8 detik setelah simpan/hapus |
| 9 | Form tidak mengingat draf bila tertutup tak sengaja | 🟡 | ✅ isian tersimpan sampai ditutup manual |
| 10 | Tidak ada cara catat transfer antar akun | 🔴 Transfer tercatat ganda jadi masuk+keluar, laporan jadi bohong | ✅ jenis **Pindah Dana** yang tidak dihitung sebagai pemasukan/pengeluaran |
| 11 | Nominal besar rawan salah nol | 🟡 | ✅ pratinjau terbilang ("dua juta lima ratus ribu") di bawah input |
| 12 | Tidak ada validasi nominal nol atau negatif | 🟢 | dipertahankan |

## B. Kebenaran Angka (13–26)

| # | Titik periksa | Vonis | Solusi |
|---|---|---|---|
| 13 | Saldo dihitung dari semua transaksi | 🟢 | dipertahankan |
| 14 | Transfer ke tabungan dihitung sebagai pengeluaran | 🔴 Bikin "pengeluaran" kelihatan membengkak padahal uang masih milik lu | ✅ pos Tabungan dipisah; laporan punya angka **pengeluaran murni** vs **uang disisihkan** |
| 15 | Rasio menabung salah hitung kalau ada transfer | 🔴 | ✅ rumus: (disisihkan + sisa) ÷ pemasukan |
| 16 | Pembulatan pakai float, rawan selisih receh | 🟡 | ✅ semua nominal disimpan sebagai bilangan bulat rupiah |
| 17 | Rata-rata harian pakai semua hari, bukan hari aktif | 🟡 | ✅ dua angka: rata-rata per hari kalender dan per hari ada transaksi |
| 18 | "Aman per hari" tidak memperhitungkan tagihan yang belum jatuh tempo | 🔴 Angkanya terlalu optimis | ✅ tagihan rutin bulan ini yang belum dibayar dipotong dulu |
| 19 | Persentase kategori dibagi total termasuk transfer | 🟡 | ✅ dibagi pengeluaran murni |
| 20 | Bulan berjalan dibandingkan bulan lalu secara penuh | 🔴 Tanggal 5 dibanding 30 hari, selalu kelihatan "hemat" | ✅ perbandingan setara: 1–21 Nov vs 1–21 Okt |
| 21 | Tidak ada median, hanya rata-rata | 🟡 Satu belanja besar merusak rata-rata | ✅ median pengeluaran harian ditampilkan |
| 22 | Proyeksi akhir bulan tidak ada | 🟡 | ✅ perkiraan total akhir bulan dari laju saat ini |
| 23 | Zona waktu pakai `toISOString` → bisa mundur sehari | 🔴 | ✅ tanggal lokal dibentuk manual dari getFullYear/Month/Date |
| 24 | Bulan dengan 28/31 hari tidak dibedakan | 🟡 | ✅ sisa hari dihitung dari jumlah hari bulan berjalan |
| 25 | Angka negatif tidak jelas tandanya | 🟡 | ✅ warna + tanda −, dan saldo minus diberi latar merah |
| 26 | Tidak ada pengecekan total alokasi = 100% | 🔴 | ✅ peringatan bila total pos ≠ 100% atau melebihi pemasukan |

## C. Fitur Alokasi "5 Juta Dibagi ke Mana" (27–38)

| # | Titik periksa | Vonis | Solusi |
|---|---|---|---|
| 27 | Fitur ini belum ada sama sekali | 🔴 Ini inti pengendalian keuangan, bukan pelengkap | ✅ halaman **Alokasi** jadi tab utama |
| 28 | Budget per kategori saja terlalu rinci untuk pemula | 🟡 11 kategori bikin lelah | ✅ 5 pos besar dulu, kategori jadi lapis kedua |
| 29 | Tidak ada template pembagian | 🟡 | ✅ template 50/30/20, 40/30/20/10, dan Kebutuhan-berat |
| 30 | Tidak terlihat sisa tiap pos | 🔴 | ✅ tiap pos: rencana, terpakai, sisa, persen |
| 31 | Tidak ada bagan pembagian | 🔴 | ✅ batang bertumpuk + donat + progress per pos |
| 32 | Pemasukan tak tetap tidak terakomodasi | 🟡 Freelancer/pedagang pemasukannya naik-turun | ✅ pemasukan rencana bisa diisi manual, bukan ikut realisasi |
| 33 | Kategori tidak terhubung ke pos | 🔴 Pengeluaran tidak otomatis mengurangi jatah pos | ✅ tiap kategori dipetakan ke satu pos, otomatis terpotong |
| 34 | Sisa pos akhir bulan hilang begitu saja | 🟡 | ✅ ringkasan akhir bulan: pos mana sisa, pos mana jebol |
| 35 | Tidak ada pos sedekah/zakat | 🟡 Relevan untuk mayoritas pengguna di Indonesia | ✅ pos Sedekah bawaan 5%, bisa dihapus |
| 36 | Tidak ada dana darurat terpisah | 🔴 | ✅ pos Dana Darurat + tujuan bawaan 6× pengeluaran bulanan |
| 37 | Alokasi tidak bisa beda tiap bulan | 🟡 | ✅ rencana disimpan per bulan |
| 38 | Tidak ada perbandingan rencana vs kenyataan | 🔴 | ✅ bagan rencana vs realisasi berdampingan |

## D. Peringatan & Pengingat (39–50)

| # | Titik periksa | Vonis | Solusi |
|---|---|---|---|
| 39 | Peringatan hanya muncul di halaman laporan | 🔴 Tidak terlihat saat dibutuhkan | ✅ panel Peringatan di paling atas Beranda |
| 40 | Tidak ada tingkatan peringatan | 🟡 | ✅ tiga tingkat: bahaya (merah), waspada (kuning), info |
| 41 | Peringatan budget baru muncul di 80% | 🟡 Sudah telat | ✅ bertingkat: 50% jika baru lewat 10 hari, 80%, 100% |
| 42 | Tidak ada peringatan laju belanja | 🔴 | ✅ "laju belanja lu 30% di atas jatah harian, kalau terus begini akhir bulan jebol Rp X" |
| 43 | Tagihan rutin tidak ada sama sekali | 🔴 Ini penyebab nomor satu budget bocor | ✅ daftar tagihan + tanggal jatuh tempo + pengingat H-3 |
| 44 | Tidak ada tanda tagihan sudah dibayar | 🟡 | ✅ tombol "Tandai lunas" yang langsung membuat transaksi |
| 45 | Tidak ada peringatan saldo menipis | 🔴 | ✅ "saldo cukup untuk X hari lagi" bila di bawah 10 hari |
| 46 | Peringatan tidak bisa ditutup | 🟡 Lama-lama diabaikan | ✅ bisa ditutup, muncul lagi besok kalau masih berlaku |
| 47 | Tidak ada notifikasi sistem | 🟡 | ⚠️ tidak gue pasang: butuh server push, dan izin notifikasi sering ditolak. Diganti pengingat dalam aplikasi + saran pasang alarm HP |
| 48 | Tidak ada peringatan transaksi janggal | 🟡 | ✅ tanda bila satu transaksi > 25% pemasukan bulanan |
| 49 | Tidak ada pengingat backup | 🔴 | ✅ peringatan bila 30 hari belum ekspor |
| 50 | Peringatan tidak memberi tindakan | 🟡 Cuma menakuti | ✅ tiap peringatan punya tombol tindakan langsung |

## E. Laporan (51–62)

| # | Titik periksa | Vonis | Solusi |
|---|---|---|---|
| 51 | Tidak ada rincian "uang gue ke mana" | 🔴 | ✅ pohon rincian: pos → kategori → 3 transaksi terbesar, lengkap nominal |
| 52 | Pie chart tanpa angka nominal | 🟡 | ✅ legenda selalu menampilkan rupiah dan persen |
| 53 | Grafik butuh pustaka eksternal | 🟡 Lambat & rawan gagal muat | ✅ semua bagan digambar sendiri dengan SVG, tanpa pustaka |
| 54 | Tidak ada perbandingan antar bulan per kategori | 🟡 | ✅ kolom naik/turun vs bulan lalu di tabel kategori |
| 55 | Tidak ada filter periode di laporan | 🟢 sudah ada di versi terakhir | dipertahankan dan dirapikan |
| 56 | Transaksi terbesar tidak disorot | 🟡 | ✅ daftar 5 pengeluaran terbesar periode berjalan |
| 57 | Tidak ada laporan per metode bayar | 🟢 | dipertahankan |
| 58 | Tidak ada hari paling boros | 🟡 | ✅ hari & tanggal paling boros ditampilkan |
| 59 | Ekspor CSV pakai titik koma, Excel Indonesia oke, Google Sheets kacau | 🟡 | ✅ pilihan pemisah koma/titik koma saat ekspor |
| 60 | Cetak PDF ikut mencetak navigasi | 🟡 | ✅ CSS cetak: navigasi & tombol disembunyikan |
| 61 | Laporan tidak bisa disalin cepat | 🟡 | ✅ tombol "Salin ringkasan" ke papan klip |
| 62 | Grafik tidak terbaca di layar kecil | 🟡 | ✅ semua bagan responsif, legenda di bawah pada layar sempit |

## F. Keandalan Data (63–74)

| # | Titik periksa | Vonis | Solusi |
|---|---|---|---|
| 63 | Data hanya di satu kunci penyimpanan | 🔴 Satu kerusakan = hilang semua | ✅ kunci utama + cadangan bergilir 3 slot |
| 64 | Tidak ada versi skema | 🔴 Update aplikasi bisa merusak data lama | ✅ field `v` + fungsi migrasi |
| 65 | Simpan tanpa pengecekan berhasil | 🟡 | ✅ status "tersimpan / gagal" terlihat |
| 66 | Penyimpanan penuh tidak ditangani | 🔴 Foto base64 cepat membuat penuh | ✅ foto dibatasi, ada penghitung pemakaian + peringatan di 80% |
| 67 | Impor cadangan tidak divalidasi | 🔴 Berkas rusak bisa menimpa data bagus | ✅ validasi struktur + konfirmasi jumlah transaksi sebelum menimpa |
| 68 | Impor selalu menimpa | 🟡 | ✅ pilihan **gabungkan** atau **timpa**, duplikat dideteksi dari id |
| 69 | Tidak ada ekspor otomatis terjadwal | 🟡 Browser tidak bisa | ✅ pengingat + ekspor sekali klik, disarankan simpan ke Drive |
| 70 | Hapus data tanpa konfirmasi ganda | 🟡 | ✅ konfirmasi + ekspor paksa sebelum hapus semua |
| 71 | Tidak ada jejak waktu ubah | 🟡 | ✅ `dibuat` dan `diubah` di tiap transaksi |
| 72 | Mode penyamaran browser menghapus data diam-diam | 🔴 | ✅ deteksi penyimpanan tidak tersedia + peringatan jelas di layar |
| 73 | Data tidak terbaca kalau JSON rusak | 🔴 | ✅ try/catch + jatuh ke cadangan terakhir yang valid |
| 74 | Tidak ada info ukuran data | 🟡 | ✅ ditampilkan di Pengaturan |

## G. Keamanan & Privasi (75–84)

| # | Titik periksa | Vonis | Solusi |
|---|---|---|---|
| 75 | Kunci API berbayar di sisi klien | 🔴 Bisa dipakai orang atas tagihan lu | ✅ fitur yang butuh kunci dihapus total dari versi ini |
| 76 | Data keuangan terbuka bila HP dipinjam | 🟡 | ✅ kunci PIN opsional saat membuka aplikasi |
| 77 | PIN disimpan apa adanya | 🔴 | ✅ disimpan sebagai hash SHA-256 lewat WebCrypto, bukan teks asli |
| 78 | PIN memberi kesan terenkripsi padahal tidak | 🟡 Jujur itu penting | ✅ keterangan jelas: PIN hanya menghalangi pandangan sekilas, bukan enkripsi |
| 79 | Repo publik berisi data contoh pribadi | 🟡 | ✅ data contoh netral, dan README menyarankan repo privat |
| 80 | Tidak ada Content Security Policy | 🟡 | ✅ meta CSP ditambahkan |
| 81 | Memuat banyak CDN pihak ketiga | 🟡 Makin banyak CDN makin besar permukaan risiko | ✅ hanya React + Babel dari satu CDN, sisanya ditulis sendiri |
| 82 | Tidak ada integritas sumber daya | 🟡 | ⚠️ SRI tidak gue pasang karena menyulitkan update versi; CDN dipilih yang resmi |
| 83 | Data terkirim ke mana saja | 🟢 Tidak ada pengiriman data sama sekali di versi ini | dipertahankan |
| 84 | Foto bukti bisa berisi info sensitif | 🟡 | ✅ keterangan bahwa foto ikut terbawa saat ekspor |

## H. Pengalaman Pakai (85–92)

| # | Titik periksa | Vonis | Solusi |
|---|---|---|---|
| 85 | Tidak ada keadaan kosong yang mengarahkan | 🟡 | ✅ layar kosong tiap halaman memberi langkah berikutnya |
| 86 | Pengguna baru langsung dihadapkan data contoh | 🟡 Bingung mana data sendiri | ✅ layar awal: mulai kosong atau pakai data contoh |
| 87 | Tidak ada penyiapan alokasi di awal | 🔴 | ✅ 3 langkah pengenalan: nama, pemasukan bulanan, pilih template alokasi |
| 88 | Area ketuk di bawah 44px | 🟡 | ✅ semua tombol minimal 44px |
| 89 | Tombol utama sulit dijangkau jempol | 🟡 | ✅ tombol tambah mengambang di kanan bawah |
| 90 | Mode gelap hanya tombol, tidak ikut sistem | 🟡 | ✅ tiga pilihan: terang, gelap, ikut sistem |
| 91 | Tidak ada dukungan luring | 🟡 Mencatat sering di tempat tanpa sinyal | ✅ service worker, aplikasi jalan penuh tanpa internet |
| 92 | Angka panjang sulit dibaca | 🟡 | ✅ angka monospace rata kanan, singkatan jt/rb di bagan |

## I. Deploy & Pemeliharaan (93–100)

| # | Titik periksa | Vonis | Solusi |
|---|---|---|---|
| 93 | Next.js + Supabase butuh terminal & env | 🔴 Terlalu berat untuk kebutuhan lu | ✅ satu berkas `index.html`, tanpa build, tanpa env |
| 94 | Supabase gratis dijeda bila 7 hari tak dibuka | 🔴 Aplikasi seumur hidup tidak boleh begitu | ✅ versi ini tidak bergantung server sama sekali |
| 95 | Vercel butuh akun tambahan | 🟡 | ✅ cukup GitHub Pages, 3 klik |
| 96 | Deploy butuh `npm install` | 🔴 | ✅ tidak ada dependensi yang dipasang |
| 97 | Update aplikasi berisiko menimpa data | 🔴 | ✅ data di localStorage terpisah dari kode; migrasi otomatis |
| 98 | Service worker lama bisa menyajikan versi usang | 🟡 | ✅ nama cache berversi + hapus cache lama saat aktivasi |
| 99 | Tidak bisa dipasang sebagai aplikasi | 🟡 | ✅ manifest + ikon, bisa Tambah ke Layar Utama |
| 100 | Tidak ada jalan sinkron antar perangkat | 🟡 Ini harga yang lu bayar demi gratis & sederhana | ⚠️ jujur: tidak ada sinkron otomatis. Gantinya ekspor/impor JSON antar perangkat, dan skema Supabase tetap tersedia kalau suatu hari lu mau sinkron |

---

## Tiga kritik paling keras

**1. Transfer ke tabungan dihitung sebagai pengeluaran.** Ini kesalahan paling merusak di versi lama. Uang yang lu sisihkan ke tabungan itu masih milik lu, bukan uang hilang. Akibatnya "pengeluaran bulan ini" kelihatan 11 juta padahal belanja beneran cuma 3,5 juta, dan rasio menabung jadi ngaco. Versi baru memisahkan **pengeluaran murni** dari **uang disisihkan**, dan menambah jenis **Pindah Dana** yang tidak masuk hitungan dua-duanya.

**2. Perbandingan antar bulan tidak setara.** Versi lama membandingkan 1–21 November dengan seluruh Oktober. Hasilnya lu selalu merasa lebih hemat sampai tanggal 28, lalu kaget. Versi baru membandingkan periode yang sama panjang, plus proyeksi akhir bulan.

**3. Peringatan datang terlambat dan di tempat yang salah.** Budget 80% baru diberitahu saat lu buka halaman laporan. Padahal yang lu butuh adalah tahu di tanggal 10 bahwa laju belanja lu akan menjebol jatah. Versi baru memindahkan peringatan ke paling atas Beranda, menambah peringatan laju belanja, tagihan jatuh tempo, dan saldo menipis — tiap peringatan dengan tombol tindakan.

## Satu hal yang gue tidak perbaiki, dan alasannya

Sinkron otomatis antar HP dan laptop. Itu butuh server, dan semua pilihan gratisnya punya syarat tersembunyi — Supabase gratis dijeda kalau 7 hari tidak dibuka. Untuk catatan yang lu niatkan seumur hidup, bergantung pada layanan gratis pihak lain justru lebih rapuh daripada satu berkas HTML yang lu pegang sendiri. Jadi pilihan gue: aplikasi sepenuhnya milik lu, dengan ekspor JSON sebagai jembatan antar perangkat. Kalau nanti lu berubah pikiran, skema Supabase yang sudah gue buat masih berlaku dan tinggal dipasang.
