/* Service worker My Finance — supaya aplikasi tetap jalan tanpa internet.
   Nama cache berversi: naikkan angkanya tiap kali index.html diubah. */
const VERSI = "myfinance-v2.0.0";
const ISI = ["./", "./index.html", "./manifest.json"];

self.addEventListener("install", e => {
  e.waitUntil(caches.open(VERSI).then(c => c.addAll(ISI)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", e => {
  e.waitUntil(
    caches.keys()
      .then(k => Promise.all(k.filter(n => n !== VERSI).map(n => caches.delete(n))))
      .then(() => self.clients.claim())
  );
});

/* Ambil dari jaringan dulu supaya pembaruan cepat terasa,
   kalau sedang luring baru pakai salinan di cache. */
self.addEventListener("fetch", e => {
  if (e.request.method !== "GET") return;
  e.respondWith(
    fetch(e.request)
      .then(res => {
        const salinan = res.clone();
        caches.open(VERSI).then(c => c.put(e.request, salinan)).catch(() => {});
        return res;
      })
      .catch(() => caches.match(e.request).then(r => r || caches.match("./index.html")))
  );
});
