# My Finance v2

Aplikasi catatan keuangan pribadi. Satu berkas HTML, jalan di HP dan laptop, tanpa pemasangan, tanpa akun, tanpa server, tanpa biaya. Semua data tersimpan di perangkat lu sendiri.

---

## Isi aplikasi

**🏠 Beranda** — kondisi keuangan dalam 5 detik
- Saldo total, pemasukan dan belanja bulan ini
- **Aman dipakai per hari** — sisa jatah dibagi sisa hari, sudah dipotong tagihan yang belum dibayar
- **Panel peringatan**: pos jebol, laju belanja terlalu cepat, tagihan jatuh tempo, anggaran 80%, saldo menipis, belum mencadangkan
- Catat kilat: pintasan sekali ketuk untuk transaksi yang sering berulang
- Pembagian bulan ini dengan progress tiap pos
- Perbandingan setara dengan bulan lalu (tanggal 1–21 vs 1–21, bukan vs sebulan penuh) dan proyeksi akhir bulan

**🧭 Alokasi** — "uang 5 juta dibagi ke mana"
- Isi pemasukan, pilih template (50/30/20, Hemat agresif, Kebutuhan berat), atau atur sendiri tiap pos
- Pos bawaan: Kebutuhan 50%, Keinginan 20%, Tabungan 20%, Dana Darurat 5%, Sedekah 5%
- Bagan batang bertumpuk dan donat, lengkap dengan rupiah dan persen
- Peringatan kalau pembagian melebihi pemasukan atau masih ada sisa yang belum ditentukan
- Bagan **rencana vs kenyataan** per pos

**🧾 Riwayat** — semua transaksi
- Saring per hari/minggu/bulan/tanggal pilihan, per jenis, kategori, metode
- Pencarian catatan, kategori, atau nominal
- Dikelompokkan per tanggal dengan selisih harian, bisa diubah dan dihapus

**📊 Laporan**
- Lingkup bulan ini / per tahun / seumur hidup
- **"Uang Rp X ini ke mana?"** — pohon rincian pos → kategori → 3 transaksi terbesar, semua ada nominalnya
- Donat kategori, tabel rincian dengan kolom naik/turun vs bulan lalu
- 5 pengeluaran terbesar, hari paling boros, median harian
- Rekap 12 bulan, rekap per tahun, perjalanan saldo, masuk vs keluar 6 bulan
- Insight otomatis, ekspor CSV, salin ringkasan, cetak PDF

**🎯 Rencana**
- Tagihan rutin dengan tanggal jatuh tempo, pengingat H-3, dan tombol "Tandai lunas" yang sekaligus membuat transaksinya
- Anggaran per kategori
- Tujuan keuangan dengan progress, tenggat, dan hitungan "sisihkan sekian per bulan"

**🏛️ Aset** — kekayaan bersih
- Daftar aset dan hutang, selisihnya jadi kekayaan bersih
- Pencocokan saldo catatan dengan tunai + bank di daftar aset

**⚙️ Lainnya** — mode gelap (bisa ikut sistem), kunci PIN, ekspor/impor cadangan, hapus data, data contoh.

---

## Yang membedakan dari versi sebelumnya

1. **Tabungan bukan pengeluaran.** Uang yang lu sisihkan ke tabungan dipisah dari "belanja murni". Laporan jadi jujur.
2. **Jenis Pindah Dana.** Transfer antar akun sendiri tidak dihitung sebagai pemasukan maupun pengeluaran.
3. **Perbandingan setara.** 1–21 November vs 1–21 Oktober, bukan vs Oktober penuh.
4. **Peringatan di depan.** Panel peringatan ada di paling atas Beranda, bertingkat, dan tiap peringatan punya tombol tindakan.
5. **Tombol Urungkan** 8 detik setelah hapus atau catat kilat.
6. **Cadangan bergilir.** Tiga slot cadangan otomatis, plus pemulihan kalau berkas utama rusak.

Rinciannya ada di `REVIEW-100.md`.

---

## Cara pasang lewat GitHub (tanpa terminal, tanpa biaya)

### 1. Buat repository
1. Buka [github.com](https://github.com) → **New repository**
2. Nama: `my-finance` · pilih **Private** · **Create repository**

### 2. Unggah berkas
1. Di halaman repo kosong, klik **uploading an existing file**
2. Seret **semua berkas** dari folder ini (bukan foldernya — isinya): `index.html`, `manifest.json`, `sw.js`, `ikon-192.png`, `ikon-512.png`, `.nojekyll`, `README.md`
3. **Commit changes**

### 3. Nyalakan GitHub Pages
1. **Settings** → menu kiri **Pages**
2. Source: **Deploy from a branch** · Branch: **main** · Folder: **/ (root)** · **Save**
3. Tunggu 1–2 menit, alamatnya muncul di halaman itu: `https://namamu.github.io/my-finance/`

> Repo **Private** di akun gratis tidak bisa pakai GitHub Pages. Kalau mau tetap gratis, jadikan repo **Public** — kodenya terbuka tapi **data keuangan lu tidak ikut**, karena data tersimpan di perangkat masing-masing, bukan di repo. Kalau tetap mau privat, pakai Netlify Drop atau Cloudflare Pages: sama-sama gratis dan terima repo privat.

### 4. Pasang di HP
- **Android (Chrome):** buka alamatnya → titik tiga → **Tambahkan ke layar utama**
- **iPhone (Safari):** buka alamatnya → ikon bagikan → **Tambah ke Layar Utama**

Setelah terpasang, aplikasi jalan penuh tanpa internet.

### Mau coba dulu tanpa GitHub?
Klik dua kali `index.html` di laptop. Jalan langsung. Catatan: mode luring (service worker) hanya aktif kalau dibuka lewat alamat web.

---

## Hal penting soal data

**Data lu ada di penyimpanan browser perangkat ini, bukan di awan.** Artinya:

- HP dan laptop punya catatan masing-masing, tidak sinkron otomatis. Pindahkan dengan ekspor–impor JSON.
- Kalau lu bersihkan data situs di browser, catatan ikut hilang.
- Mode penyamaran tidak menyimpan apa-apa — aplikasi akan memberi peringatan merah kalau terdeteksi.

**Karena itu: unduh cadangan tiap bulan** lewat Pengaturan → Unduh cadangan, simpan di Google Drive lu. Aplikasi akan mengingatkan sendiri kalau sudah lewat 30 hari. Itu satu-satunya salinan yang benar-benar lu pegang.

**Kunci PIN** hanya menghalangi orang yang pinjam HP melihat isi aplikasi. Itu bukan enkripsi — data di perangkat tetap bisa dibaca lewat cara lain. Jangan anggap ini pengaman kuat.

**Notifikasi** hanya muncul di dalam aplikasi, tidak sampai ke layar kunci HP. Push notification butuh server. Kalau mau diingatkan mencatat tiap malam, pasang alarm berulang di HP jam 21.00.

---

## Kalau mau diubah nanti

Semua ada di `index.html`. Bagian yang paling sering ingin diubah:

| Mau ubah apa | Cari bagian |
|---|---|
| Kategori, ikon, warna | `const KAT_KELUAR` dan `const KAT_MASUK` |
| Pos alokasi & persen bawaan | `const POS_BAWAAN` |
| Template pembagian | `const TEMPLAT` |
| Aturan peringatan | `function peringatan(db)` |
| Warna aplikasi | blok `:root` di bagian `<style>` |

Setelah mengubah `index.html`, naikkan juga angka `VERSI` di `sw.js` supaya versi lama di cache tidak tersaji. Data lu tidak ikut terhapus saat memperbarui kode — keduanya tersimpan terpisah.
